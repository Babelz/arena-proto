require "player"
require "mapping"

-- b2 world
game_physics_world = nil;

local player_force = 9000;

-- player
local player;

function love.load() 
	game_physics_world = love.physics.newWorld(0.0, 9.81, false);

	mappings = {
		new_mapping("w", function() player.body:applyForce(0, -player_force * 10) end, STATE_PRESSED),
		new_mapping("a", function() player.body:applyForce(-player_force, 0) end, STATE_DOWN),
		new_mapping("s", function() player.body:applyForce(0, player_force) end, STATE_DOWN),
		new_mapping("d", function() player.body:applyForce(player_force, 0) end, STATE_DOWN)
	};

	player = new_player(mappings);
end

function love.update(dt)
	player.update();

	game_physics_world:update(dt);
end

function love.draw() 
	player.draw();
end