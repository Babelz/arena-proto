require "math"
require "babytils"
require "input_handler"

function new_player(mappings)
	local this = { };

	this.index 			= index;
	this.texture 		= nil;
	this.input_handler  = new_input_handler(mappings);

	-- create body
	this.body = love.physics.newBody(game_physics_world, 0, 0, "dynamic")
	this.body:setMass(70);

	this.update = function() 
		-- update
		this.input_handler.listen();
    end

    this.draw = function()
    	-- draw
    	x, y = this.body:getPosition();

    	love.graphics.rectangle("fill", x, y, 32, 32);
	end

	return this;
end