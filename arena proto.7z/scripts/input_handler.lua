require "babytils"

function new_input_handler(mappings)
	assert(not mappings == nil, "mappings can't be nil");

	local this = { };

	this.mappings = mappings;

	this.listen = function() 
		foreach(this.mappings, 
			function(mapping)
				isKeyDown = love.keyboard.isDown(mapping.key);

				mapping.old_state = mapping.cur_state;

								
			end);
		end

	return this;
end