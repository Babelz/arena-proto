require "babytils"

STATE_PRESSED 	= 0;
STATE_DOWN 		= 1;
STATE_RELEASED 	= 2;

function new_mapping(key, action, state_trigger) 
	assert(key == nil, "key can't be nil");
	assert(action == nil, "action can't be nil");
	assert(state_trigger == nil, "state can't be nil");

	local this = { };

	this.key 				= key;
	this.action 			= action;
	this.state_trigger 		= state_trigger;
	this.cur_state 			= state_trigger;
	this.old_state 			= state_trigger;

	return this;
end