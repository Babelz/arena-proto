function foreach(container, action) 
	for i = 1, table.getn(container) do action(container[i]) end
end

function find(container, predicate)
	for i = 1, table.getn(container) do if predicate(container[i]) then return container[i] end end

	return nil;
end

function assert(condition, message) 
	if not condition then return end

	print(message)

	while 1 == 1 do end
end