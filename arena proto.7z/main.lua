require "player"
require "mapping"

-- b2 world
game_physics_world = nil;
-- player
local player;

function love.load() 
	game_physics_world = love.physics.newWorld(0.0, 9.81, false);

	mappings = {
		new_mapping("w", function() player.position.y = player.position.y - 5.0 end, STATE_DOWN),
		new_mapping("a", function() player.position.x = player.position.x - 5.0 end, STATE_DOWN),
		new_mapping("s", function() player.position.y = player.position.y + 5.0 end, STATE_DOWN),
		new_mapping("d", function() player.position.x = player.position.x + 5.0 end, STATE_DOWN)
	};

	player = new_player(mappings);
end

function love.update()
	player.update();
end

function love.draw() 
	player.draw();
end